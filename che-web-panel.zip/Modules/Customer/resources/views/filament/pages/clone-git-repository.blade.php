

<x-filament-panels::page>

    <div class="mt-4">
        {{$this->form}}
    </div>

</x-filament-panels::page>
