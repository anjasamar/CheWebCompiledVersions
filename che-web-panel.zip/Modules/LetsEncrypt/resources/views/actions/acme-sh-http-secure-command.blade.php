/usr/local/che/web/Modules/LetsEncrypt/shell/acme.sh --issue -d {{$domain}} --webroot {{$domainPublic}}
