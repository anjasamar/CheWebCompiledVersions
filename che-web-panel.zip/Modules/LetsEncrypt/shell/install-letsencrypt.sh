# install certbot
sudo apt-get install certbot -y

echo "Done!"
