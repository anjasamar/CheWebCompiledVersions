<?php

namespace App;

class ApiClient
{
    public static function getChePHP()
    {
        return '/usr/local/che/php/bin/php';
    }
}
