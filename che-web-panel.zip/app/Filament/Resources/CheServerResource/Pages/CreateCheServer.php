<?php

namespace App\Filament\Resources\CheServerResource\Pages;

use App\Filament\Resources\CheServerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCheServer extends CreateRecord
{
    protected static string $resource = CheServerResource::class;
}
