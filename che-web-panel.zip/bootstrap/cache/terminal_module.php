<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Terminal\\App\\Providers\\TerminalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Terminal\\App\\Providers\\TerminalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);